from sys_prompts import get_attacker_system_prompt, get_evaluator_system_prompt_for_judge, get_evaluator_system_prompt_for_on_topic
from langchain.chat_models import ChatOllama, ChatOpenAI
from langchain.llms import CTransformers
from langchain.schema import HumanMessage, SystemMessage
from tqdm import tqdm
from utils import extract_nested_json_with_stack

chat_model =  ChatOllama(
            model="mixtral:8x7b-instruct-v0.1-q4_K_S",
            temperature = 0.7
        )

judge_model = ChatOllama(
            model="mixtral:8x7b-instruct-v0.1-q4_K_S",
            temperature = 0, 
            top_k=10,
            top_p=0.5
        )

class Attacker:
    def __init__(self, objective, target):
        self.chat_model = chat_model
        self.judge_model = judge_model
        self.objective = objective
        self.target = target
        self.initial_message =  get_attacker_system_prompt(objective, target)

    def make_move(self, history):
        if not history:
            history.append(SystemMessage(content=self.initial_message, speaker="system"))

        # Query the chat model again for the next move
        valid_ans = False
        history.append(HumanMessage(content = "Give the next attack in the JSON form {\"improvement\": \"\",\"prompt\": \"}"))

        max_attempts = 3
        attempts = 0


        while attempts < max_attempts:
            response = self.chat_model(history)
            move = response.content.strip()
            move_json = extract_nested_json_with_stack(move)
            if move_json and "prompt" in move_json.keys():
                valid_ans = True
                break
            else:
                print(move)
                attempts += 1

        if not valid_ans:
            move_json = {"improvement": "None", "prompt": "This line failed, please prune this."}

        prompt = move_json["prompt"]
        # Update history with the model's response
        history.append(HumanMessage(content=str(move), speaker="model"))
        return prompt, history

    def judge_response(self, history, defender_response):
        # Prepare a message asking the chat model to judge the defender's response
        judgment_prompt = get_evaluator_system_prompt_for_judge(self.objective, self.target)
        # Feed only the judgment prompt to the chat model
        judge_prompts = [
            SystemMessage(content=judgment_prompt, speaker="system"),
            HumanMessage(content = defender_response,  speaker = "target")
        ]
        response = self.judge_model(judge_prompts)
        judgment = response.content.strip()  # Assuming the last message is the chat model's judgment
        
        
        # Update history with the model's judgment
        history.append(SystemMessage(content=judgment, speaker="judge"))

        return judgment, history
    
    def judge_prompt(self, history, attacker_strategy):
        # Prepare a message asking the chat model to judge the defender's response
        judgment_prompt = get_evaluator_system_prompt_for_on_topic(self.objective)
        # Feed only the judgment prompt to the chat model
        judge_prompts = [
            SystemMessage(content=judgment_prompt, speaker="system"),
            HumanMessage(content=str(attacker_strategy), speaker = "model")
        ]
        response = self.judge_model(judge_prompts)
        judgment = response.content.strip()  # Assuming the last message is the chat model's judgment
    
        # Update history with the model's judgment
        history.append(SystemMessage(content=judgment, speaker="judge"))

        return judgment, history 

# Defender class using CTransformers
class Defender:
    def __init__(self):
        self.llm = CTransformers(
            model ="TheBloke/Llama-2-7B-Chat-GGUF", 
            model_file="llama-2-7b-chat.Q4_K_M.gguf", 
            model_type="llama",
            gpu_layers=50
        )

    def respond(self, history, attacker_strategy):
        defender_response = ''
        while len(defender_response) < 10:
            defender_response = self.llm(attacker_strategy)
        history.append(HumanMessage(content = defender_response, speaker = "target"))
        return defender_response, history