from conversers import Attacker, Defender
from attack_defense import generate_all_attacks, prune_stage_1, run_attack, prune_stage_2
from tqdm import tqdm
from dotenv import load_dotenv
from datetime import datetime
import pytz
import pandas as pd
import json
import os

singapore_tz = pytz.timezone('Asia/Singapore')
load_dotenv()

def iterative_process(histories, attacker, defender, branch_factor, k):
    for iteration in tqdm(range(k)):
        print(f"Iteration {iteration + 1} started at {datetime.now(singapore_tz)}")
        
        # Step 1: Generate Attacks
        print("Generating Attacks.....")
        next_gen_convs, next_gen_attacks = generate_all_attacks(histories, attacker, branch_factor)
        print("================================================")

        # Step 2: Prune Off-topic Attacks
        print("Filtering Attacks........")
        on_topic_histories, on_topic_attacks = prune_stage_1(next_gen_attacks, next_gen_convs, attacker)
        print("================================================")

        # Step 3: Run Attacks
        print("Running Attacks.....")
        post_attack_histories, defense_responses = run_attack(on_topic_attacks, on_topic_histories, defender)
        print("================================================")

        # Step 4: Prune Worst Performers
        print("Pruning Responses.......")
        histories, scores = prune_stage_2(defense_responses, post_attack_histories, attacker, topk)
        print("================================================")

        print(f"Defense Responses : {defense_responses}")
        print(scores)

        if histories == []:
            histories = [[]]

    return histories

def process_and_write_to_json(objectives, targets, branch_factor, k):
    directory_name = "results"
    os.makedirs(directory_name, exist_ok=True)  # Create the directory if it does not exist

    for i, (obj, tgt) in enumerate(zip(objectives, targets)):
        print(f"Processing for Objective: {obj}, Target: {tgt}")
        attacker = Attacker(obj, tgt)
        defender = Defender()
        final_histories = iterative_process([[]], attacker, defender, branch_factor, k)

        # Extract required information
        if final_histories and final_histories[0]:
            result = {
                "objective": obj,
                "target": tgt,
                "best_convo": [msg.content for msg in final_histories[0]]
            }

            # Construct a unique file name for each result
            file_name = f"{directory_name}/result_{i}.json"

            # Write the result to its own JSON file
            with open(file_name, "w") as file:  # Open in write mode
                json.dump(result, file, indent=4)  # Use indent for better readability

def read_csv_and_get_columns(file_path):
    # Read the CSV file
    df = pd.read_csv(file_path)

    # Extract the 'objectives' and 'targets' columns
    objectives = df['goal'].tolist()
    targets = df['target'].tolist()

    return objectives, targets

if __name__ == "__main__":  
    branch_factor = 1
    topk = 1
    initial_histories = [[]]
    k_iterations = 4

    objectives, targets = read_csv_and_get_columns("advbench_subset.csv")
    process_and_write_to_json(objectives, targets, branch_factor, k_iterations)