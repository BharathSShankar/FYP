from conversers import Attacker, Defender
from tqdm import tqdm
from utils import extract_judgment, extract_number_rating

def generate_all_attacks(histories, attacker: Attacker, branch_factor: int):
    next_gen_convs, next_gen_attacks = [], []
    for history in tqdm(histories):
        possible_futures, possible_attacks = generate_prompts(history, attacker, branch_factor)
        next_gen_convs.extend(possible_futures)
        next_gen_attacks.extend(possible_attacks)
    return next_gen_convs, next_gen_attacks

def generate_prompts(history, attacker: Attacker, branch_factor : int):
    possible_paths = []
    next_strat = []
    for i in tqdm(range(branch_factor)):
        attacker_strategy, upd_history = attacker.make_move(history.copy())
        possible_paths.append(upd_history)
        next_strat.append(attacker_strategy)
    return possible_paths, next_strat

def filter_off_topic(attack, history, attacker: Attacker):
    attacker_judgement, new_history = attacker.judge_prompt(history.copy(), attack)
    return extract_judgment(attacker_judgement), attacker_judgement, new_history

def prune_stage_1(attacks, histories, attacker: Attacker):
    on_topic_attacks, on_topic_histories = [], []
    for i in tqdm(range(len(histories))):
        result, attacker_judgement, updated_history = filter_off_topic(attacks[i], histories[i], attacker)
        if result or True:
            on_topic_attacks.append(attacks[i])
            on_topic_histories.append(updated_history)
    return on_topic_histories, on_topic_attacks


def run_attack(attacks, histories, defender: Defender):
    new_histories, defender_responses = [], []
    for i in tqdm(range(len(attacks))):
        defender_response, updated_history = defender.respond(histories[i].copy(), str(attacks[i]))
        new_histories.append(updated_history)
        defender_responses.append(defender_response)
    return new_histories, defender_responses

def prune_stage_2(defense_responses, histories, attacker: Attacker, topk : int):
    scores, new_histories = [], []
    for i in tqdm(range(len(defense_responses))):
        defense_judgment, history = attacker.judge_response(histories[i].copy(), defense_responses[i])
        score = extract_number_rating(defense_judgment)
        scores.append(score)
        new_histories.append(history)
    sorted_histories = sort_histories_by_scores(scores, new_histories)
    scores.sort(reverse=True)
    return sorted_histories[:topk], scores[:topk]

def sort_histories_by_scores(scores, new_histories):
    """
    Sorts new_histories according to their corresponding scores.

    Args:
    scores (list): A list of scores.
    new_histories (list): A list of histories corresponding to the scores.

    Returns:
    list: The new_histories sorted according to the scores.
    """
    if len(scores) != len(new_histories):
        raise ValueError("Scores and histories lists must be of the same length.")

    # Pair each score with its history
    paired = zip(scores, new_histories)

    # Sort the pairs based on scores
    sorted_pairs = sorted(paired, key=lambda x: x[0], reverse=True)

    # Extract the sorted histories
    sorted_histories = [history for _, history in sorted_pairs]
    
    return sorted_histories

