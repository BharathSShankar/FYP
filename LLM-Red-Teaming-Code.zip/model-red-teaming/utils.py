import json
import re

def extract_nested_json_with_stack(response_str):
    """
    Extracts a nested JSON object from a string using a stack-based approach.

    Parameters:
    response_str (str): The string containing the JSON data.

    Returns:
    dict or None: A dictionary containing the extracted JSON data, or None if no JSON found.
    """
    stack = []
    json_start_index = None

    for i, char in enumerate(response_str):
        if char == '{':
            stack.append(char)
            if len(stack) == 1:
                # Mark the start of the outermost JSON object
                json_start_index = i
        elif char == '}' and stack:
            stack.pop()
            if not stack and json_start_index is not None:
                # End of the outermost JSON object
                json_end_index = i
                try:
                    return json.loads(response_str[json_start_index:json_end_index + 1])
                except json.JSONDecodeError:
                    print(response_str)
                    return None

    return None


def extract_number_rating(prompt):
    """
    Extracts a numeric rating enclosed in double brackets from a prompt.

    Args:
    prompt (str): The text prompt containing the rating.

    Returns:
    str: The extracted numeric rating or 'Rating not found' if no rating is present.
    """
    # Regular expression pattern to match [[number]]
    pattern = r'\[\[(\d+)\]\]'
    match = re.search(pattern, prompt)
    if match:
        return int(match.group(1))
    else:
        return 1

def extract_judgment(response: str):
    return "YES" in response
